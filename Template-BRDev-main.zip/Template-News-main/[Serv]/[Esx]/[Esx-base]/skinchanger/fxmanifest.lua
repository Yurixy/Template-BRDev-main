fx_version 'adamant'
game 'gta5'

client_scripts {
	'locale.lua',
	'locales/fr.lua',
	'config.lua',
	'client/main.lua'
}
