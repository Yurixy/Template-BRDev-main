---
id: 19
name: 'flags'
---
List of connection flags to use other than the default ones. It is also possible to blacklist default ones.
For more information, check [Connection Flags](https://github.com/mysqljs/mysql#connection-flags).