---
id: 20
name: 'ssl'
---
Object with ssl parameters or a string containing name of ssl profile. See [SSL options](https://github.com/mysqljs/mysql#ssl-options).