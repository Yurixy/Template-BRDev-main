---
id: 16
name: 'trace'
---
Generates stack traces on `Error` to include call site of library entrance ("long stack traces").
Slight performance penalty for most calls. (Default: `true`)